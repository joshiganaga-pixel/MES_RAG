import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  ScrollView, StyleSheet, StatusBar, Keyboard,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { search, STATS } from '../utils/search';
import { C, DOC, SAMPLES } from '../utils/theme';

// ─── Chunk Card ───────────────────────────────────────────────────────────────
function ChunkCard({ item, rank }) {
  const [open, setOpen] = useState(false);
  const m = DOC[item.doc] || { label: item.doc, bg: '#555', lt: '#eee', br: '#999' };
  const isTop = rank <= 3;
  return (
    <View style={[s.card, { borderColor: isTop ? m.br : C.border }]}>
      <View style={s.cardTop}>
        <View style={[s.docTag, { backgroundColor: m.bg }]}>
          <Text style={s.docTagTxt}>#{rank}  {m.label}</Text>
        </View>
        <View style={[s.scorePill, { backgroundColor: m.lt, borderColor: m.br }]}>
          <Text style={[s.scoreTxt, { color: m.bg }]}>{item.score}</Text>
        </View>
        <Text style={s.pgTxt}>pg≈{item.page_approx}</Text>
      </View>

      <Text style={s.heading} numberOfLines={open ? 0 : 2}>{item.heading || '(section)'}</Text>
      {item.chapter ? <Text style={s.breadcrumb}>{item.chapter}</Text> : null}

      <View style={[s.snippetBox, open && s.snippetOpen]}>
        <Text style={s.snippetTxt} numberOfLines={open ? 0 : 5}>{item.snippet}</Text>
      </View>

      <TouchableOpacity onPress={() => setOpen(o => !o)} style={s.toggleBtn}>
        <Text style={[s.toggleTxt, { color: m.bg }]}>{open ? '▲ less' : '▼ more'}</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── About Modal ──────────────────────────────────────────────────────────────
function AboutOverlay({ onClose }) {
  return (
    <View style={s.overlay}>
      <View style={s.aboutCard}>
        <View style={s.aboutHeader}>
          <Text style={s.aboutTitle}>MES RAG</Text>
          <TouchableOpacity onPress={onClose}><Text style={s.closeBtn}>✕</Text></TouchableOpacity>
        </View>
        <View style={s.statGrid}>
          {[['Total Chunks', STATS.total], ['RMES 1968', STATS.rmes],
            ['SoA 2022', STATS.soa], ['Vocabulary', STATS.vocab]].map(([l, v]) => (
            <View key={l} style={s.statCard}>
              <Text style={s.statVal}>{v.toLocaleString()}</Text>
              <Text style={s.statLbl}>{l}</Text>
            </View>
          ))}
        </View>
        <Text style={s.aboutBody}>
          {'Fully offline BM25 retrieval.\nNo internet. No server. No API key.\n\nMilitary Engineer Services\nEngineer-in-Chief\'s Branch\nIntegrated HQ of MoD (Army)\n\nRMES 1968 (Reprint 1982)\nSoA 2022'}
        </Text>
        <TouchableOpacity style={s.closeFullBtn} onPress={onClose}>
          <Text style={s.closeFullTxt}>Close</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── Home Screen ──────────────────────────────────────────────────────────────
export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [query,     setQuery]     = useState('');
  const [filter,    setFilter]    = useState('all');
  const [hits,      setHits]      = useState([]);
  const [searched,  setSearched]  = useState(false);
  const [noResult,  setNoResult]  = useState(false);
  const [showAbout, setShowAbout] = useState(false);

  const runSearch = useCallback((q) => {
    const qt = (typeof q === 'string' ? q : query).trim();
    if (!qt) return;
    Keyboard.dismiss();
    setSearched(true); setNoResult(false);
    const fd = filter === 'all' ? null : filter;
    const results = search(qt, 10, fd);
    setHits(results);
    if (!results.length) setNoResult(true);
  }, [query, filter]);

  const docCounts = hits.reduce((a, h) => ({ ...a, [h.doc]: (a[h.doc] || 0) + 1 }), {});

  return (
    <View style={[s.root, { paddingTop: insets.top }]}>
      <StatusBar backgroundColor={C.dark} barStyle="light-content" />

      {/* Header */}
      <View style={s.header}>
        <View style={s.badgeRow}>
          <View style={s.mesBadge}><Text style={s.mesTxt}>MES</Text></View>
          <View style={s.rmesBadge}><Text style={s.docBadgeTxt}>RMES 1968</Text></View>
          <View style={s.soaBadge}><Text style={s.docBadgeTxt}>SoA 2022</Text></View>
          <View style={s.offlinePill}><Text style={s.offlineTxt}>● OFFLINE</Text></View>
          <TouchableOpacity onPress={() => setShowAbout(true)} style={s.infoBtn}>
            <Text style={s.infoBtnTxt}>ℹ</Text>
          </TouchableOpacity>
        </View>
        <Text style={s.title}>MES Regulations & Scales</Text>
        <Text style={s.subtitle}>{STATS.total} chunks · {STATS.vocab.toLocaleString()} terms · Fully offline</Text>
      </View>

      {/* Search */}
      <View style={s.searchBox}>
        <View style={s.inputRow}>
          <TextInput
            style={s.input}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={() => runSearch()}
            placeholder="e.g. Technical sanction powers for GE…"
            placeholderTextColor={C.mute}
            returnKeyType="search"
            autoCorrect={false}
            autoCapitalize="none"
          />
          <TouchableOpacity
            style={[s.btn, !query.trim() && s.btnOff]}
            onPress={() => runSearch()}
            disabled={!query.trim()}
          >
            <Text style={s.btnTxt}>Search</Text>
          </TouchableOpacity>
        </View>

        {/* Doc filter */}
        <View style={s.filterRow}>
          {[['all','Both'],['RMES','RMES 1968'],['SoA2022','SoA 2022']].map(([v, l]) => (
            <TouchableOpacity key={v}
              onPress={() => { setFilter(v); if (searched && query.trim()) runSearch(query); }}
              style={[s.chip, filter === v && s.chipOn]}>
              <Text style={[s.chipTxt, filter === v && s.chipTxtOn]}>{l}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Sample chips */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.samplesRow}>
          {SAMPLES.map((sm, i) => (
            <TouchableOpacity key={i} style={s.sChip}
              onPress={() => { setQuery(sm.q); runSearch(sm.q); }}>
              <Text style={s.sChipTxt}>{sm.l}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Results */}
      {!searched ? (
        <View style={s.empty}>
          <Text style={s.emptyIcon}>📋</Text>
          <Text style={s.emptyTitle}>MES Query Assistant</Text>
          <Text style={s.emptyDesc}>
            {'Search RMES 1968 and SoA 2022.\nWorks completely offline.\nNo internet. No API key. No server.'}
          </Text>
        </View>
      ) : noResult ? (
        <View style={s.empty}>
          <Text style={s.emptyIcon}>🔍</Text>
          <Text style={s.emptyTitle}>No results found</Text>
          <Text style={s.emptyDesc}>Try different or broader keywords.</Text>
        </View>
      ) : (
        <FlatList
          data={hits}
          keyExtractor={item => String(item.id)}
          renderItem={({ item, index }) => <ChunkCard item={item} rank={index + 1} />}
          contentContainerStyle={s.listPad}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <View style={s.sourceRow}>
              <Text style={s.sourceLbl}>FOUND  </Text>
              {Object.entries(docCounts).map(([doc, cnt]) => {
                const m = DOC[doc] || { bg: '#555', label: doc };
                return (
                  <View key={doc} style={[s.srcBadge, { backgroundColor: m.bg }]}>
                    <Text style={s.srcBadgeTxt}>{m.label}: {cnt}</Text>
                  </View>
                );
              })}
              <Text style={s.totalTxt}> · {hits.length} total</Text>
            </View>
          }
        />
      )}

      {/* About overlay */}
      {showAbout && <AboutOverlay onClose={() => setShowAbout(false)} />}
    </View>
  );
}

const s = StyleSheet.create({
  root:        { flex:1, backgroundColor:C.bg },

  // Header
  header:      { backgroundColor:C.dark, paddingHorizontal:16, paddingBottom:12, paddingTop:6 },
  badgeRow:    { flexDirection:'row', alignItems:'center', gap:6, marginBottom:8, flexWrap:'wrap' },
  mesBadge:    { backgroundColor:C.gold, borderRadius:4, paddingHorizontal:8, paddingVertical:2 },
  mesTxt:      { color:C.dark, fontWeight:'800', fontSize:10, letterSpacing:1.5 },
  rmesBadge:   { backgroundColor:'#1a3a6e', borderRadius:4, paddingHorizontal:8, paddingVertical:2 },
  soaBadge:    { backgroundColor:C.green, borderRadius:4, paddingHorizontal:8, paddingVertical:2 },
  docBadgeTxt: { color:'#a8c0f0', fontWeight:'700', fontSize:10, letterSpacing:1 },
  offlinePill: { backgroundColor:'rgba(168,200,138,.15)', borderRadius:10, paddingHorizontal:8, paddingVertical:2, borderWidth:1, borderColor:'rgba(168,200,138,.3)', marginLeft:'auto' },
  offlineTxt:  { color:'#a8c88a', fontSize:9, fontWeight:'700', letterSpacing:.8 },
  infoBtn:     { padding:4 },
  infoBtnTxt:  { color:C.gold, fontSize:18 },
  title:       { color:'#f4f1eb', fontSize:17, fontWeight:'700' },
  subtitle:    { color:'#8aaa8a', fontSize:11, marginTop:2, fontFamily:'sans-serif', letterSpacing:.4 },

  // Search
  searchBox:   { backgroundColor:'#fffbf0', borderBottomWidth:2, borderBottomColor:C.gold, paddingHorizontal:14, paddingTop:12, paddingBottom:10 },
  inputRow:    { flexDirection:'row', gap:8, marginBottom:10 },
  input:       { flex:1, borderWidth:1.5, borderColor:C.gold, borderRadius:8, paddingHorizontal:12, paddingVertical:10, fontSize:14, color:C.text, backgroundColor:'#fffdf5' },
  btn:         { backgroundColor:C.primary, borderRadius:8, paddingHorizontal:16, justifyContent:'center', alignItems:'center', minWidth:80 },
  btnOff:      { backgroundColor:'#aaa' },
  btnTxt:      { color:'#fff', fontWeight:'700', fontSize:13 },
  filterRow:   { flexDirection:'row', alignItems:'center', gap:6, marginBottom:10, flexWrap:'wrap' },
  chip:        { borderWidth:1.5, borderColor:'#ccc', borderRadius:14, paddingHorizontal:12, paddingVertical:4, backgroundColor:'#fff' },
  chipOn:      { borderColor:C.gold, backgroundColor:C.gold },
  chipTxt:     { fontSize:11, color:C.sub, fontWeight:'500' },
  chipTxtOn:   { color:C.primary, fontWeight:'700' },
  samplesRow:  { marginTop:2 },
  sChip:       { backgroundColor:C.goldLt, borderWidth:1, borderColor:C.gold, borderRadius:14, paddingHorizontal:12, paddingVertical:5, marginRight:6 },
  sChipTxt:    { fontSize:11, color:C.primary, fontWeight:'500' },

  // Empty
  empty:       { flex:1, alignItems:'center', justifyContent:'center', padding:32 },
  emptyIcon:   { fontSize:52, marginBottom:14 },
  emptyTitle:  { fontSize:16, fontWeight:'700', color:C.primary, marginBottom:8 },
  emptyDesc:   { fontSize:13, color:C.sub, lineHeight:21, textAlign:'center' },

  // Results header
  sourceRow:   { flexDirection:'row', alignItems:'center', gap:6, paddingHorizontal:14, paddingTop:12, paddingBottom:6, flexWrap:'wrap' },
  sourceLbl:   { fontSize:10, color:C.mute, fontWeight:'700', letterSpacing:1 },
  srcBadge:    { borderRadius:10, paddingHorizontal:10, paddingVertical:3 },
  srcBadgeTxt: { color:'#fff', fontSize:11, fontWeight:'700' },
  totalTxt:    { fontSize:11, color:C.mute },
  listPad:     { paddingHorizontal:14, paddingBottom:20 },

  // Chunk card
  card:        { backgroundColor:C.surface, borderWidth:1.5, borderRadius:10, padding:14, marginBottom:10 },
  cardTop:     { flexDirection:'row', alignItems:'center', gap:6, marginBottom:7, flexWrap:'wrap' },
  docTag:      { borderRadius:4, paddingHorizontal:8, paddingVertical:2 },
  docTagTxt:   { color:'#fff', fontSize:10, fontWeight:'700', letterSpacing:.5 },
  scorePill:   { borderWidth:1, borderRadius:4, paddingHorizontal:6, paddingVertical:1 },
  scoreTxt:    { fontSize:10, fontWeight:'600' },
  pgTxt:       { fontSize:10, color:C.mute, marginLeft:'auto' },
  heading:     { fontSize:13, fontWeight:'600', color:C.text, lineHeight:18, marginBottom:4 },
  breadcrumb:  { fontSize:10, color:C.mute, marginBottom:6 },
  snippetBox:  { backgroundColor:'#fafaf5', borderRadius:6, padding:10, borderWidth:1, borderColor:'#eee', marginBottom:8, overflow:'hidden' },
  snippetOpen: { },
  snippetTxt:  { fontFamily:'monospace', fontSize:11.5, color:C.text, lineHeight:17 },
  toggleBtn:   { alignItems:'center', paddingTop:2 },
  toggleTxt:   { fontSize:11, fontWeight:'700' },

  // About overlay
  overlay:     { position:'absolute', top:0, left:0, right:0, bottom:0, backgroundColor:'rgba(0,0,0,.6)', justifyContent:'center', alignItems:'center', padding:24 },
  aboutCard:   { backgroundColor:C.surface, borderRadius:12, padding:20, width:'100%', maxWidth:400 },
  aboutHeader: { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:16 },
  aboutTitle:  { fontSize:18, fontWeight:'700', color:C.primary },
  closeBtn:    { fontSize:20, color:C.mute, padding:4 },
  statGrid:    { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:16 },
  statCard:    { backgroundColor:C.bg, borderRadius:8, padding:12, alignItems:'center', minWidth:'44%', flex:1 },
  statVal:     { fontSize:22, fontWeight:'700', color:C.primary },
  statLbl:     { fontSize:10, color:C.mute, marginTop:2, letterSpacing:.5 },
  aboutBody:   { fontSize:12, color:C.sub, lineHeight:19, textAlign:'center', marginBottom:16 },
  closeFullBtn:{ backgroundColor:C.primary, borderRadius:8, padding:12, alignItems:'center' },
  closeFullTxt:{ color:'#fff', fontWeight:'700', fontSize:14 },
});
