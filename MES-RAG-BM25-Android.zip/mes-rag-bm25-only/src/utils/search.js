import INDEX from './bm25Index';

const SW = new Set('a an the and or but in on at to for of with by from is are was were be been has have had do does did will would could should may might shall can not no nor so if it its this that these those i we you he she they all any each every some such other per as also than then when where which who'.split(' '));

export function tokenise(t) {
  return (t.toLowerCase().match(/[a-z0-9]+/g) || []).filter(w => !SW.has(w) && w.length > 1);
}

export function search(query, topK = 10, docFilter = null) {
  const { chunks, idf, inv_index, avgdl, N, dl } = INDEX;
  const k1 = 1.5, b = 0.75;
  const qt = tokenise(query);
  if (!qt.length) return [];
  const scores = new Float32Array(N);
  for (const t of qt) {
    if (!idf[t] || !inv_index[t]) continue;
    for (const [di, tf] of Object.entries(inv_index[t])) {
      const i = parseInt(di, 10);
      if (docFilter && chunks[i].doc !== docFilter) continue;
      scores[i] += idf[t] * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl[i] / avgdl));
    }
  }
  return Array.from(scores.entries())
    .filter(([, s]) => s > 0).sort((a, c) => c[1] - a[1]).slice(0, topK)
    .map(([i, s]) => ({ ...chunks[i], score: +(s.toFixed(2)) }));
}

export const STATS = {
  total: INDEX.N,
  rmes:  INDEX.chunks.filter(c => c.doc === 'RMES').length,
  soa:   INDEX.chunks.filter(c => c.doc === 'SoA2022').length,
  vocab: Object.keys(INDEX.idf).length,
};
