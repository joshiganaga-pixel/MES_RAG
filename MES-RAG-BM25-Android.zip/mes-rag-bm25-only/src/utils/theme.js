export const C = {
  primary:'#1a2e1a', dark:'#0d1f0d', gold:'#c8a84b', goldLt:'#f0e8d0',
  navy:'#1a3a6e', navyLt:'#e8eef8', navyBr:'#3a6abf',
  green:'#2d4a1e', greenLt:'#eef5e8', greenBr:'#5a8a3a',
  bg:'#f4f1eb', surface:'#fff', border:'#ddd',
  text:'#1a1a1a', sub:'#555', mute:'#888',
};
export const DOC = {
  RMES:    { label:'RMES 1968', bg:'#1a3a6e', lt:'#e8eef8', br:'#3a6abf' },
  SoA2022: { label:'SoA 2022',  bg:'#2d4a1e', lt:'#eef5e8', br:'#5a8a3a' },
};
export const SAMPLES = [
  { l:'Technical sanction — GE/CWE/CE',   q:'Technical sanction powers for GE CWE and CE' },
  { l:'Admin approval — original works',   q:'Administrative approval powers for original works' },
  { l:'Contractor bill payment',           q:'Procedure preparation payment contractor bills' },
  { l:'Security deposit — staff',          q:'Security deposit amounts MES civilian storekeeper cashier' },
  { l:'Transfer of charge',               q:'Procedure transfer of charge handing over taking over' },
  { l:'Married accommodation — Colonel',  q:'Married accommodation floor area scale Colonel' },
  { l:'Gymnasium — Class I station',      q:'Gymnasium floor area scale Class I station' },
  { l:'Periodical maintenance',           q:'Normal periodical services maintenance buildings' },
  { l:'Earnest money — tenders',          q:'Earnest money security deposits contractor tenders' },
  { l:'Single accommodation — JCO',       q:'Single living accommodation scale JCOs' },
  { l:'E&M maintenance',                  q:'Maintenance operation E M installations MES' },
  { l:'Loss regularisation',              q:'Regularisation losses MES stores procedure' },
];
