# MES RAG — Offline Android APK

RMES 1968 + SoA 2022 · BM25 Search · Zero internet · Zero install complexity

---

## Get the APK in 5 steps (no PC needed)

### Step 1 — Create free GitHub account
Go to **github.com** → Sign up (free)

### Step 2 — Create new repository
- Click **+** → New repository
- Name: `mes-rag`
- Set to **Private** (recommended) or Public
- Click **Create repository**

### Step 3 — Upload these files
- Click **uploading an existing file**
- Drag and drop the entire contents of this zip
- Commit message: `Initial commit`
- Click **Commit changes**

### Step 4 — Watch it build
- Click **Actions** tab at the top
- You will see **Build MES RAG APK** running (takes ~10 minutes)
- Wait for green ✓

### Step 5 — Download APK
- Click the completed workflow run
- Scroll down to **Releases** section on the main page
- Or go to **Releases** → download `MES-RAG.apk`
- Direct link will be:
  `https://github.com/YOUR-USERNAME/mes-rag/releases/latest`

---

## Install on Android

1. Open the release link on your phone
2. Tap **MES-RAG.apk** → Download
3. Open notification → tap file
4. If blocked: Settings → Apps → Special app access → Install unknown apps → Chrome → Allow
5. Tap **Install**

---

## App Features

- **Instant BM25 search** — results appear as you hit Search
- **632 chunks** — RMES 1968 (346) + SoA 2022 (286)
- **8,750 vocabulary terms**
- **Document filter** — Both / RMES 1968 only / SoA 2022 only
- **12 sample queries** — horizontal scroll chips
- **Expandable chunk cards** — tap ▼ more to read full text
- **Colour coded** — Navy = RMES, Green = SoA
- **ℹ About** — index statistics overlay
- **100% offline** — no internet, no server, no API key ever needed

---

## Future updates

To release a new APK version, just push any change to the `main` branch.
GitHub Actions rebuilds automatically and creates a new release.
